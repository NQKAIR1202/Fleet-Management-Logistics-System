import {
  Card,
  CardContent,
  Typography,
  Table,
  TableHead,
  TableRow,
  TableCell,
  TableBody,
  Chip,
} from "@mui/material";

const alerts = [
  {
    vehicle: "VN-1025",
    type: "Overspeed",
    severity: "High",
  },
  {
    vehicle: "VN-2041",
    type: "Brake Warning",
    severity: "Medium",
  },
  {
    vehicle: "VN-3107",
    type: "Engine Fault",
    severity: "High",
  },
  {
    vehicle: "VN-1189",
    type: "Low Battery",
    severity: "Low",
  },
];

function getColor(level) {
  switch (level) {
    case "High":
      return "error";
    case "Medium":
      return "warning";
    default:
      return "success";
  }
}

function RecentAlerts() {
  return (
    <Card
      elevation={2}
      sx={{
        borderRadius: 2,
        height: "100%",
      }}
    >
      <CardContent>

        <Typography
          variant="h6"
          fontWeight="bold"
          mb={2}
        >
          Recent Alerts
        </Typography>

        <Table size="small">

          <TableHead>

            <TableRow>

              <TableCell>Vehicle</TableCell>

              <TableCell>Alert</TableCell>

              <TableCell>Status</TableCell>

            </TableRow>

          </TableHead>

          <TableBody>

            {alerts.map((item) => (

              <TableRow key={item.vehicle}>

                <TableCell>

                  {item.vehicle}

                </TableCell>

                <TableCell>

                  {item.type}

                </TableCell>

                <TableCell>

                  <Chip
                    label={item.severity}
                    color={getColor(item.severity)}
                    size="small"
                  />

                </TableCell>

              </TableRow>

            ))}

          </TableBody>

        </Table>

      </CardContent>
    </Card>
  );
}

export default RecentAlerts;