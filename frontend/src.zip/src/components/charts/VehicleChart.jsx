import {
  PieChart,
  Pie,
  Cell,
  ResponsiveContainer,
  Tooltip,
  Legend,
} from "recharts";

const data = [
  { name: "Available", value: 280 },
  { name: "Assigned", value: 145 },
  { name: "Maintenance", value: 52 },
  { name: "Out of Service", value: 23 },
];

const COLORS = [
  "#2E7D32",
  "#1565C0",
  "#ED6C02",
  "#D32F2F",
];

function VehicleChart() {
  return (
    <ResponsiveContainer width="100%" height={340}>
      <PieChart>
        <Pie
          data={data}
          dataKey="value"
          nameKey="name"
          innerRadius={65}
          outerRadius={110}
          paddingAngle={3}
        >
          {data.map((entry, index) => (
            <Cell
              key={entry.name}
              fill={COLORS[index % COLORS.length]}
            />
          ))}
        </Pie>

        <Tooltip />

        <Legend
          verticalAlign="bottom"
          height={36}
        />
      </PieChart>
    </ResponsiveContainer>
  );
}

export default VehicleChart;