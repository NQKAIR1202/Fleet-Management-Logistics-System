import { Typography } from "@mui/material";

function Vehicles() {
  return (
    <>
      <Typography variant="h4" fontWeight="bold">
        Vehicles
      </Typography>

      <Typography color="text.secondary" sx={{ mt: 1 }}>
        Manage all fleet vehicles.
      </Typography>
    </>
  );
}

export default Vehicles;